<?php

use App\Http\Controllers\admin\AdminController;
use App\Http\Controllers\admin\BrandController;
use App\Http\Controllers\admin\CategoryController;
use App\Http\Controllers\admin\ColorController;
use App\Http\Controllers\admin\ProductController;
use App\Http\Controllers\admin\SizeController;
use App\Http\Controllers\admin\subCategoryController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

/*------------------admin route--------------*/
Route::prefix('admin')->group( function() {
    //admin login----
    Route::get('/login', [AdminController::class, 'index'])->name('admin.login');
    Route::post('/login/create', [AdminController::class, 'login'])->name('login.create');

    Route::middleware('admin')->group( function(){
        // admin register route----
        Route::get('/register', [AdminController::class, 'AdminRegister'])->name('admin.register');
        Route::post('/register/insert', [AdminController::class, 'AdminRegisterInsert'])->name('register.insert');

        Route::get('/dashboard', [AdminController::class, 'dashboard'])->name('admin.dashboard');
        Route::get('/logout', [AdminController::class, 'logout'])->name('admin.logout');

        Route::get('/profile',[AdminController::class, 'profile'])->name('admin.profile');
        Route::post('/profile/update',[AdminController::class, 'profile_update'])->name('admin.profile.update');
        Route::get('/password/change',[AdminController::class, 'password_change'])->name('admin.change.password');
        Route::post('/password/update',[AdminController::class, 'password_update'])->name('admin.password.update');
        //category

        Route::resource('category',CategoryController::class);
        //subcategory
        Route::resource('subCategory',subCategoryController::class);
        //Brand
        Route::resource('brand',BrandController::class);
        //color
        Route::resource('color',ColorController::class);
        //color
        Route::resource('size',SizeController::class);
        // product
        Route::post('/getCategory', [ProductController::class, 'getCategory']);
        Route::get('/product/create', [ProductController::class, 'create'])->name('product.create');
        Route::post('/product/store', [ProductController::class, 'store'])->name('product.store');

    });
});

/*------------------admin route end--------------*/


Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
