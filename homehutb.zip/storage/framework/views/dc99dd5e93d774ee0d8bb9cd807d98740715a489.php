<?php $__env->startSection('title', '| Edit Size'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-8 grid-margin stretch-card m-auto">
        <div class="card mt-5">
          <div class="card-body">
            <h4 class="card-title">Edit Size</h4>
            <!----alerat------->
            <?php if(Session::has('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong><?php echo e(session::get('success')); ?></strong>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <?php endif; ?>
            <form action="<?php echo e(url('/admin/size/'.$size_id->id)); ?>" method="post" class="forms-sample">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
              <div class="form-group row">
                <label for="name" class="col-sm-3 col-form-label">Size Name</label>
                <div class="col-sm-9">
                  <input type="text" name="name" class="form-control" id="name" value="<?php echo e($size_id->name); ?>">
                  <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger"><?php echo e($message); ?></p>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>

              <button type="submit" class="btn btn-primary mr-2">Save</button>
            </form>
          </div>
        </div>
      </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HomeHutBd\resources\views/admin/size/edit.blade.php ENDPATH**/ ?>