<?php $__env->startSection('title', '| Admin Profile'); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-6 grid-margin stretch-card m-auto">
        <div class="card mt-5">
          <div class="card-body">
            <h4 class="card-title">Profile</h4>
            <!----alerat profile update------->
            <?php if(Session::has('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong><?php echo e(session::get('success')); ?></strong>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <?php endif; ?>
            <form action="<?php echo e(route('admin.profile.update')); ?>" method="POST" class="forms-sample" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="admin_id" value="<?php echo e($profile->id); ?>">
              <div class="form-group row">
                <label for="exampleInputUsername2" class="col-sm-3 col-form-label">User Name</label>
                <div class="col-sm-9">
                  <input type="text" name="username" class="form-control" id="exampleInputUsername2"  value="<?php echo e($profile->username); ?>">
                  <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>
              <div class="form-group row">
                <label for="exampleInputPhone" class="col-sm-3 col-form-label">Phone</label>
                <div class="col-sm-9">
                  <input type="text" name="phone" class="form-control" id="exampleInputPhone" value="<?php echo e($profile->phone); ?>">
                  <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>
              <div class="form-group row">
                <label for="exampleInputEmail" class="col-sm-3 col-form-label">Email</label>
                <div class="col-sm-9">
                  <input type="text" name="email" class="form-control" id="exampleInputEmail" value="<?php echo e($profile->email); ?>">
                  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>
              <div class="form-group row">
                <label for="exampleInputImage" class="col-sm-3 col-form-label">Profile Image</label>
                <div class="col-sm-9">
                  <input type="file" name="profile_image" class="form-control" id="exampleInputImage">
                  <?php $__errorArgs = ['profile_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  <img class="mt-2" src="<?php echo e(asset('storage/backend/admin/'.$profile->profile_image)); ?>" height="80px" width="90px">
                </div>
              </div>
              <button type="submit" class="btn btn-primary mr-2">Save</button>
            </form>
          </div>
        </div>
      </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HomeHutBd\resources\views/admin/profile.blade.php ENDPATH**/ ?>