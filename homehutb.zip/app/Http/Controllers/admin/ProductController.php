<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use App\Models\Brand;
use App\Models\Category;
use App\Models\Color;
use App\Models\Size;
use App\Models\Subcategory;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    public function index(){
        //
    }

    public function create(){
        $categories =Category::all();
        // $SubCategories =Subcategory::all();
        $Brands =Brand::all();
        $colors =Color::all();
        $sizes =Size::all();
        return view('admin.product.add_product',[
            'categories'=>$categories,
            // 'SubCategories'=>$SubCategories,
            'Brands'=>$Brands,
            'colors'=>$colors,
            'sizes'=>$sizes,
        ]);
    }
    public function store(Request $request){

    }

    public function getCategory(Request $request){
        $stores ='<option value="">--Subcategories--</option>';
        foreach(Subcategory::where('category',$request->category)->get() as $subCategory){
            $stores.= '<option value ="'.$subCategory->id.'">'.$subCategory->category.'</option>';
        }
        

    }
}
