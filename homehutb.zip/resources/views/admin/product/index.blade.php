@extends('layouts.admin.app')
@section('title', '| Add Cayegory')
@section('content')

<div class="row">
    <div class="col-md-8"></div>
</div>

@endsection
