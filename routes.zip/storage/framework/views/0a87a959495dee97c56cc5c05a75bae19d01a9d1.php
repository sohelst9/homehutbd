<?php $__env->startSection('front_title' ,'/ Checkout'); ?>
<?php $__env->startSection('shop_content'); ?>
<style>
    .select2-container .select2-selection--single{
        height:35px;
    }
    .select2-container .select2-selection--single .select2-selection__rendered{
        padding-top:2px;
    }
    .form-control{
        border:1px solid #9A9FAE;
    }
    .select2-container--default .select2-selection--single{
        border-radius: 0px;
    }

</style>
  <!-- Page Header Start -->
  <div style="margin-top:20px">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('frontend.index')); ?>" style="margin-left: 47px;">Home</a></li>
            <li class="breadcrumb-item"><a>Shop</a></li>
            <li class="breadcrumb-item active">Checkout</li>
        </ol>
    </nav>
</div>
<!-- Page Header End -->


<!-- Checkout Start -->
<div class="container-fluid pt-5">
    <form action="<?php echo e(route('order')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="row px-xl-5">
            <div class="col-lg-8">
                <div class="mb-4">
                    <h4 class="font-weight-semi-bold mb-4">Billing Address</h4>
                    <div class="row">
                        <?php
                            $user= Auth::user();
                        ?>
                        <div class="col-md-6 form-group">
                            <label>First Name</label>
                            <input class="form-control" name="fname" type="text" value="<?php echo e($user->fname); ?>">
                            <?php $__errorArgs = ['fname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6 form-group">
                            <label>Last Name</label>
                            <input class="form-control" name="lname" type="text" value="<?php echo e($user->lname); ?>">
                            <?php $__errorArgs = ['lname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6 form-group">
                            <label>E-mail</label>
                            <input class="form-control" name="email" type="text" value="<?php echo e($user->email); ?>">
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6 form-group">
                            <label>Mobile No</label>
                            <input class="form-control" name="number" type="text" value="<?php echo e($user->phone); ?>">
                            <?php $__errorArgs = ['number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6 form-group">
                            <label>Country</label>
                            <select class="form-control" id="country" name="country" selected>
                                <option value="1" selected>Bangladesh</option>
                            </select>
                        </div>
                        <div class="col-md-6 form-group">
                            <label>Division</label>
                            <select class="form-control" id="division" name="division">
                                <?php $__currentLoopData = $divisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $division): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($division->id); ?>"><?php echo e($division->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['division'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="col-md-6 form-group">
                            <label>District</label>
                            <select class="form-control" id="district" name="district">
                            </select>
                            <?php $__errorArgs = ['district'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6 form-group">
                            <label>Sub District</label>
                            <select class="form-control" id="sub_district" name="sub_district">
                                <option>-Select-</option>
                            </select>
                            <?php $__errorArgs = ['sub_district'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="col-md-6 form-group">
                            <label>State</label>
                            <input class="form-control" name="state" type="text">
                            <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6 form-group">
                            <label>ZIP Code</label>
                            <input class="form-control" name="zip_code" type="text">
                            <?php $__errorArgs = ['zip_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-12 form-group">
                            <label>Address Line</label>
                            <textarea name="address" class="form-control"></textarea>
                            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-12 form-group">
                            <label>Order Notes</label>
                            <textarea name="order_note" class="form-control"></textarea>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="card border-secondary mb-5">
                    <div class="card-header bg-secondary border-0">
                        <h4 class="font-weight-semi-bold m-0">Order Total</h4>
                    </div>
                    <div class="card-body">
                        <h5 class="font-weight-medium mb-3">Products</h5>
                        <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="d-flex justify-content-between" style="font-size: 14px;">
                                <p><?php echo e(substr($cart->product->productName, 0, 30).'..'); ?>  X <?php echo e($cart->quntity); ?></p>
                                <p><span>&#2547;</span><?php echo e($cart->product->after_discount*$cart->quntity); ?></p>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <hr class="mt-0">
                        <div class="d-flex justify-content-between mb-3 pt-1">
                            <h6 class="font-weight-medium">Subtotal</h6>
                            <input type="hidden" name="subtotal" id="subtotal" value="<?php echo e(session('subtotal')); ?>">
                            <h6 class="font-weight-medium">&#2547;<?php echo e(session('subtotal')); ?></h6>
                        </div>
                        <div class="d-flex justify-content-between">
                            <h6 class="font-weight-medium">Discount</h6>
                            <input type="hidden" name="product_discount" value="<?php echo e(session('discount')); ?>">
                            <h6 class="font-weight-medium"><?php echo e(session('discount')); ?>%</h6>
                        </div>

                        <div class="d-flex justify-content-between">
                            <div class="">
                                <h6 class="font-weight-medium">Delivery Charge</h6>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="delevery_charge" id="inside_valu" value="60">
                                    <label class="form-check-label" for="inside_valu">Inside Dhaka <span style="margin-left:212px">&#2547; <span>60</span></span></label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="delevery_charge" id="outside_valu" value="120">
                                    <label class="form-check-label" for="outside_valu">Out Side Dhaka <span style="margin-left:187px">&#2547; <span>120</span></span></label>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="card-footer border-secondary bg-transparent">
                        <div class="d-flex justify-content-between mt-2">
                            <h5 class="font-weight-bold">Total</h5>
                            <input type="hidden" id="total" name="total"value="<?php echo e(session('total')); ?>">
                            <h5 class="font-weight-bold">&#2547;<span  id="grand_total"><?php echo e(session('total')); ?></span></h5>
                        </div>
                    </div>
                </div>
                <?php $__errorArgs = ['payment_method'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="card border-secondary mb-5">
                    <div class="card-header bg-secondary border-0">
                        <h4 class="font-weight-semi-bold m-0">Payment</h4>
                    </div>
                    <div class="card-body">
                        <div class="form-group">
                            <div class="custom-control custom-radio">
                                <input type="radio" class="custom-control-input" name="payment_method" id="Cash_on_delivery" value="1">
                                <label class="custom-control-label" for="Cash_on_delivery">Cash on Delivery</label>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="custom-control custom-radio">
                                <input type="radio" class="custom-control-input" name="payment_method" id="ssl_commerze" value="2">
                                <label class="custom-control-label" for="ssl_commerze">SSL Commerze</label>
                            </div>
                        </div>
                        <div class="">
                            <div class="custom-control custom-radio">
                                <input type="radio" class="custom-control-input" name="payment_method" id="banktransfer" value="3">
                                <label class="custom-control-label" for="banktransfer">Bank Transfer</label>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer border-secondary bg-transparent">
                        <button type="submit" class="btn btn-lg btn-block btn-primary font-weight-bold my-3 py-3">Place Order</button>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>
<!-- Checkout End -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

    <script>
       // ----selcet 2----
        $(document).ready(function() {
            $('#country').select2();
        });

        $(document).ready(function() {
            $('#division').select2();
        });

        $(document).ready(function() {
            $('#district').select2();
        });

        $(document).ready(function() {
            $('#sub_district').select2();
        });


        //delivery charge--
        $('#inside_valu').click(function(){
            var total = parseInt($('#total').val());
            var inside_value = parseInt($('#inside_valu').val());
            var g_total = total + inside_value;
            $('#grand_total').html(g_total);
        })

        $('#outside_valu').click(function(){
            var total = parseInt($('#total').val());
            var inside_value = parseInt($('#outside_valu').val());
            var g_total = total + inside_value;
            $('#grand_total').html(g_total);
        })

    </script>

    <!----division select district select subdistrict ajax ---->
    <script>
        $('#division').change(function(){
            var division_id = $('#division').val();
            var url = "<?php echo e(route('district')); ?>";

            $.ajax({
                type: "post",
                url: url,
                data: {'division_id':division_id},
                success: function (data) {
                    $('#district').html(data);
                    $('#sub_district').html('');
                }
            });
        })

        $('#district').change(function(){
            var district_id = $('#district').val();
            var url = "<?php echo e(route('sub_district')); ?>";

            $.ajax({
                type: "post",
                url: url,
                data: {'district_id':district_id},
                success: function (data) {
                    $('#sub_district').html(data);
                }
            });
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend.shop.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HomeHutBd\resources\views/frontend/checkout/index.blade.php ENDPATH**/ ?>