<?php $__env->startSection('title', '| Edit Product'); ?>
<?php $__env->startSection('content'); ?>
<style>

</style>
<form action="<?php echo e(route('product.update')); ?>" method="POST" class="" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="col-md-8">
            <!----product info start-->
            <div class="card mt-5">
                <div class="card-body">
                    <h4 class="card-title">Edit Product</h4>
                    <input type="hidden" name="id" value="<?php echo e($products->id); ?>">
                    <!---product Name--->
                    <div class="form-group row">
                        <label for="ProductName" class="col-sm-3 col-form-label">Product Name <span class="text-danger">*</span></label>
                        <div class="col-sm-9">
                        <input type="text" name="ProductName" class="form-control" id="ProductName" value="<?php echo e($products->productName); ?>">
                        <?php $__errorArgs = ['ProductName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <!---product Category--->
                    <div class="form-group row">
                        <label for="category" class="col-sm-3 col-form-label">Category <span class="text-danger">*</span></label>
                        <div class="col-sm-9">
                            <select class="js-example-basic-single" style="width:100%" name="category" id="category">
                                <option value="">--Categories--</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>" <?php echo e($category->id == $products->category_id ? 'selected' : ''); ?>><?php echo e($category->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <!---product SubCategory--->
                    <div class="form-group row">
                        <label for="subcategory" class="col-sm-3 col-form-label">SubCategory <span class="text-danger">*</span></label>
                        <div class="col-sm-9">
                        <select name="subcategory" id="subcategory" class="js-example-basic-single" style="width:100%">
                            <option value="">--Subcategories--</option>
                            <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($subcategory->id); ?>"
                                <?php echo e($subcategory->id == $products->subcategory_id ? 'selected' : ''); ?>>
                                <?php echo e($subcategory->subcategory); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['subcategory'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <!---product Brand--->
                    <div class="form-group row">
                        <label for="brand" class="col-sm-3 col-form-label">Brand</label>
                        <div class="col-sm-9">
                        <select name="brand" id="brand" class="js-example-basic-single" style="width:100%">
                            <option value="">--Brand--</option>
                            <?php $__currentLoopData = $Brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($Brand->id); ?>" <?php echo e($Brand->id == $products->brand_id ? 'selected' : ''); ?>><?php echo e($Brand->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        </div>
                    </div>
                    <!---product Weight--->
                    <div class="form-group row">
                        <label for="weight" class="col-sm-3 col-form-label">Weight</label>
                        <div class="col-sm-9">
                        <input type="text" name="weight" class="form-control" id="weight" placeholder="0.00 g/kg" value="<?php echo e($products->weight); ?>">
                        </div>
                    </div>
                    <!---product Barcode--->
                    <div class="form-group row">
                        <label for="barcode" class="col-sm-3 col-form-label">Barcode <span class="text-danger">*</span></label>
                        <div class="col-sm-9">
                        <input type="text" name="barcode" class="form-control" id="barcode" value="<?php echo e($products->barcode); ?>">
                        <?php $__errorArgs = ['barcode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                </div>
            </div>
            <!----start  product image-->
            <div class="card mt-2">
                <div class="card-body">
                    <h4 class="card-title">Product Image</h4>
                    <!---product Image--->
                    <div class="form-group row">
                        <label for="galleryImage" class="col-sm-3 col-form-label">Gallery Image <span class="text-light">(600x600)</span></label>
                        <div class="col-sm-9">
                        <input type="file" multiple name="galleryImage[]" class="form-control" id="galleryImage">
                        <?php $__currentLoopData = $products->galleryImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                       <div class="delete_img" style="display: inline-block;">
                            <img class="mt-2" src="<?php echo e(asset('storage/backend/upload/product/galleryImage/'.$gallery->gallery)); ?>" height="80px" width="90px">
                            <button style="padding:0px; margin-top: -54px; margin-left: -25px;" type="button" class="galleryImageDelete btn btn-danger btn-small" value="<?php echo e($gallery->id); ?>"><i class="mdi mdi-backspace" ></i></button>
                       </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <!---Thumbnail Image--->
                    <div class="form-group row">
                        <label for="ThumbnailImage" class="col-sm-3 col-form-label">Thumbnail Image <span class="text-danger">*</span> <span class="text-light">(400x400)</span></label>
                        <div class="col-sm-9">
                        <input type="file" name="ThumbnailImage" class="form-control" id="ThumbnailImage">
                        <img class="mt-2" src="<?php echo e(asset('storage/backend/upload/product/thumbnailImage/'.$products->thumbnailImage)); ?>" height="80px" width="90px">
                        <?php $__errorArgs = ['ThumbnailImage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                </div>
            </div>
            
            <!----start  product price and Stock-->
            <div class="card mt-2">
                <div class="card-body">
                    <h4 class="card-title">Product Price and Stock</h4>
                    <!---product price--->
                    <div class="form-group row">
                        <label for="ProductPrice" class="col-sm-3 col-form-label">Product Price <span class="text-danger">*</span></label>
                        <div class="col-sm-9">
                        <input type="number" name="ProductPrice" class="form-control" id="ProductPrice" value="<?php echo e($products->productPrice); ?>">
                        <?php $__errorArgs = ['ProductPrice'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <!---product discount date Range--->
                    <div class="form-group row">
                        <label for="discountDate" class="col-sm-3 col-form-label">Discount Date Range</label>
                        <div class="col-sm-9">
                        <input type="date" name="discountDate" class="form-control" id="discountDate" value="">
                        </div>
                    </div>
                    <!---product discount--->
                    <div class="form-group row">
                        <label for="discount" class="col-sm-3 col-form-label">Discount <span class="text-light">(%)</span></label>
                        <div class="col-sm-9">
                        <input type="text" name="discount" class="form-control" id="discount" value="<?php echo e($products->discount); ?>">
                        </div>
                    </div>

                    <!---product Quantity--->
                    <div class="form-group row">
                        <label for="quantity" class="col-sm-3 col-form-label">Quantity <span class="text-danger">*</span></label>
                        <div class="col-sm-9">
                        <input type="number" name="quantity" class="form-control" id="quantity" value="<?php echo e($products->quantity); ?>">
                        <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                </div>
            </div>
                <!----start  product Description-->
                <div class="card mt-2">
                <div class="card-body">
                    <h4 class="card-title">Product Description</h4>
                    <!---Description--->
                    <div class="form-group row">
                        <label for="description" class="col-sm-3 col-form-label">Description <span class="text-danger">*</span></label>
                        <div class="col-sm-9">
                            <textarea name="description" id="description" cols="30" rows="10" class="form-control"><?php echo e($products->description); ?></textarea>
                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
            </div>
            <!----start  product Seo Meta Tags-->
            <div class="card mt-2">
                <div class="card-body">
                    <h4 class="card-title">Seo Meta Tags</h4>
                    <!---meta title--->
                    <div class="form-group row">
                        <label for="metaTitle" class="col-sm-3 col-form-label">Meta Title <span class="text-danger">*</span></label>
                        <div class="col-sm-9">
                            <input type="text" name="metaTitle" class="form-control" id="metaTitle" value="<?php echo e($products->meta_title); ?>">
                        <?php $__errorArgs = ['metaTitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                        <!---meta description--->
                    <div class="form-group row">
                        <label for="metaDescription" class="col-sm-3 col-form-label">MetaDescription</label>
                        <div class="col-sm-9">
                            <textarea name="metaDescription" id="metaDescription" cols="30" rows="10" class="form-control"><?php echo e($products->meta_descp); ?></textarea>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <!----Featured status-->
            <div class="card mt-2">
                <div class="card-body">
                    <h4 class="card-title">Featured</h4>
                    <div class="form-group row">
                        <label class="col-sm-6 col-form-label" style="margin-top:9px;">Status</label>
                        <div class="col-sm-3">
                          <div class="form-check">
                            <label class="form-check-label">
                              <input type="radio" class="form-check-input" name="featured" value="off" <?php echo e($products->featured =="off" ? 'checked' : ''); ?>>off </label>
                          </div>
                        </div>
                        <div class="col-sm-3">
                          <div class="form-check">
                            <label class="form-check-label">
                              <input type="radio" class="form-check-input" name="featured" value="on" <?php echo e($products->featured =="on" ? 'checked' : ''); ?>>on </label>
                          </div>
                        </div>
                    </div>
                </div>
            </div>
            <!----Todays Deal status-->
            <div class="card mt-2">
                <div class="card-body">
                    <h4 class="card-title">Todays Deal</h4>
                    <div class="form-group row">
                        <label class="col-sm-6 col-form-label" style="margin-top:9px;">Status</label>
                        <div class="col-sm-3">
                          <div class="form-check">
                            <label class="form-check-label">
                              <input type="radio" class="form-check-input" name="todayDeal" value="off" <?php echo e($products->to_day_deal =="off" ? 'checked' : ''); ?>>off </label>
                          </div>
                        </div>
                        <div class="col-sm-3">
                          <div class="form-check">
                            <label class="form-check-label">
                              <input type="radio" class="form-check-input" name="todayDeal" value="on" <?php echo e($products->to_day_deal =="on" ? 'checked' : ''); ?>>on </label>
                          </div>
                        </div>
                    </div>
                </div>
            </div>
             <!----Flash Deal-->
             <div class="card mt-2">
                <div class="card-body">
                    <h4 class="card-title">Flash Deal</h4>
                    <div class="form-group">
                        <label class="col-form-label">Add to Flash</label>
                        <select name="addTosFlash" class="form-control" >
                            <option value="">Select Flash</option>
                            <option value="winterSell">Winter Sell</option>
                            <option value="flashDeal">Flash Deal</option>
                            <option value="flashSeal">Flash Seal</option>
                        </select>
                    </div>
                </div>
            </div>
            <!---- vat and tax-->
            <div class="card mt-2">
                <div class="card-body">
                    <h4 class="card-title">Vat and Tax</h4>
                    <div class="form-group">
                        <label class="col-form-label">Vat <span>(taka)</span></label>
                        <input type="number" name="vat" class="form-control" value="<?php echo e($products->vat); ?>">
                    </div>
                    <div class="form-group">
                        <label class="col-form-label">Tax <span>(taka)</span></label>
                        <input type="number" name="tax" class="form-control" value="<?php echo e($products->tax); ?>">
                    </div>
                </div>
            </div>
        </div>

        <div class="mt-4">
            <button type="submit" class="btn btn-primary mr-2">Save & Publish</button>
        </div>
    </div>
</form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
   <script>
     $('#category').change(function(){
        var category = $('#category').val();

        $.ajax({
            type:'POST',
            url:'/getCategory',
            data:{'category_id':category},
            success:function(data){
                $('#subcategory').html(data);

            }
        });
     });


     //galleryImageDelete
     $(document).on('click', '.galleryImageDelete', function(){
        var gallery_id = $(this).val();
        var thisclick =$(this);
        $.ajax({
            type:'GET',
            url:"/admin/galleryImage/"+gallery_id+"/delete",
            data:{
                'product_color_id':gallery_id
            },
            success: function(response){
                alert(response.message);
                thisclick.closest('.delete_img').remove();
            }
        });
     });
   </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HomeHutBd\resources\views/admin/product/edit.blade.php ENDPATH**/ ?>