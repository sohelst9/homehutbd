<?php $__env->startSection('title', '| Coupons'); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-6">
        <a style="text-decoration:none; color:white;" href="<?php echo e(route('coupon.index')); ?>"><h1 class="h3">All Coupon</h1></a>
    </div>
    <div class="col-md-6 text-md-right">
        <a href="<?php echo e(route('coupon.create')); ?>" class="btn btn-primary">
            <span>Add New Coupon</span>
        </a>
    </div>
    <div class="col-lg-12 mt-3">
        <div class="card">
            <div class="card-body">
                 <!----alerat profile update------->
            <?php if(Session::has('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong><?php echo e(session::get('success')); ?></strong>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <?php endif; ?>
                <div class="table-responsive">
                    <table class="table table-dark" id="category">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Dicount</th>
                            <th>Validity</th>
                            <th style="width:100px">Option</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <tr>
                            <td><?php echo e($key+1); ?></td>
                            <td><?php echo e($coupon->name); ?></td>
                            <td><?php echo e($coupon->discount); ?></td>
                            <td><?php echo e($coupon->validity); ?></td>
                            <td>
                                <a href="" class="btn btn-small btn-primary">edit</a>
                                <a href="" class="btn btn-small btn-danger">Delete</a>
                            </td>
                           </tr>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HomeHutBd\resources\views/admin/Coupon/index.blade.php ENDPATH**/ ?>