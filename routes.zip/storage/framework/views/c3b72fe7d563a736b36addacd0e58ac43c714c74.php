<?php $__env->startSection('title', '| Add Product'); ?>
<?php $__env->startSection('content'); ?>
<style>

</style>
    <!----alerat------->
    <?php if(Session::has('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong><?php echo e(session::get('success')); ?></strong>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <?php endif; ?>
<form action="<?php echo e(route('product.store')); ?>" method="POST" class="" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="col-md-8">
            <!----product info start-->
            <div class="card mt-5">
                <div class="card-body">
                    <h4 class="card-title">Product Information</h4>
                    <!---product Name--->
                    <div class="form-group row">
                        <label for="ProductName" class="col-sm-3 col-form-label">Product Name <span class="text-danger">*</span></label>
                        <div class="col-sm-9">
                        <input type="text" name="ProductName" class="form-control" id="ProductName">
                        <?php $__errorArgs = ['ProductName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <!---product Category--->
                    <div class="form-group row">
                        <label for="category" class="col-sm-3 col-form-label">Category <span class="text-danger">*</span></label>
                        <div class="col-sm-9">
                            <select class="js-example-basic-single" style="width:100%" name="category" id="category">
                                <option value="">--Categories--</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <!---product SubCategory--->
                    <div class="form-group row">
                        <label for="subcategory" class="col-sm-3 col-form-label">SubCategory <span class="text-danger">*</span></label>
                        <div class="col-sm-9">
                        <select name="subcategory" id="subcategory" class="js-example-basic-single" style="width:100%">
                            <option value="">--Subcategories--</option>
                        </select>
                        <?php $__errorArgs = ['subcategory'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <!---product Brand--->
                    <div class="form-group row">
                        <label for="brand" class="col-sm-3 col-form-label">Brand</label>
                        <div class="col-sm-9">
                        <select name="brand" id="brand" class="js-example-basic-single" style="width:100%">
                            <option value="">--Brand--</option>
                            <?php $__currentLoopData = $Brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($Brand->id); ?>"><?php echo e($Brand->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        </div>
                    </div>
                    <!---product Weight--->
                    <div class="form-group row">
                        <label for="weight" class="col-sm-3 col-form-label">Weight</label>
                        <div class="col-sm-9">
                        <input type="text" name="weight" class="form-control" id="weight" placeholder="0.00 g/kg">
                        </div>
                    </div>
                    <!---product Barcode--->
                    <div class="form-group row">
                        <label for="barcode" class="col-sm-3 col-form-label">Barcode <span class="text-danger">*</span></label>
                        <div class="col-sm-9">
                        <input type="text" name="barcode" class="form-control" id="barcode">
                        <?php $__errorArgs = ['barcode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                </div>
            </div>
            <!----start  product image-->
            <div class="card mt-2">
                <div class="card-body">
                    <h4 class="card-title">Product Image</h4>
                    <!---product Image--->
                    <div class="form-group row">
                        <label for="galleryImage" class="col-sm-3 col-form-label">Gallery Image <span class="text-light">(600x600)</span></label>
                        <div class="col-sm-9">
                        <input type="file" multiple name="galleryImage[]" class="form-control" id="galleryImage">
                        </div>
                    </div>
                    <!---Thumbnail Image--->
                    <div class="form-group row">
                        <label for="ThumbnailImage" class="col-sm-3 col-form-label">Thumbnail Image <span class="text-danger">*</span> <span class="text-light">(400x400)</span></label>
                        <div class="col-sm-9">
                        <input type="file" name="ThumbnailImage" class="form-control" id="ThumbnailImage">
                        <?php $__errorArgs = ['ThumbnailImage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                </div>
            </div>
            
            <!----start  product price and Stock-->
            <div class="card mt-2">
                <div class="card-body">
                    <h4 class="card-title">Product Price and Stock</h4>
                    <!---product price--->
                    <div class="form-group row">
                        <label for="ProductPrice" class="col-sm-3 col-form-label">Product Price <span class="text-danger">*</span></label>
                        <div class="col-sm-9">
                        <input type="number" name="ProductPrice" class="form-control" id="ProductPrice">
                        <?php $__errorArgs = ['ProductPrice'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <!---product discount date Range--->
                    <div class="form-group row">
                        <label for="discountDate" class="col-sm-3 col-form-label">Discount Date Range</label>
                        <div class="col-sm-9">
                        <input type="date" name="discountDate" class="form-control" id="discountDate">
                        </div>
                    </div>
                    <!---product discount--->
                    <div class="form-group row">
                        <label for="discount" class="col-sm-3 col-form-label">Discount <span class="text-light">(%)</span></label>
                        <div class="col-sm-9">
                        <input type="text" name="discount" class="form-control" id="discount">
                        </div>
                    </div>

                    

                </div>
            </div>
            <!----start  product Description-->
            <div class="card mt-2">
                <div class="card-body">
                    <h4 class="card-title">Product Description</h4>
                    <!---Description--->
                    <div class="form-group row">
                        <label for="description" class="col-sm-3 col-form-label">Description <span class="text-danger">*</span></label>
                        <div class="col-sm-9">
                            <textarea name="description" id="description" cols="30" rows="10" class="form-control"></textarea>
                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
            </div>
            <!----start  product Seo Meta Tags-->
            <div class="card mt-2">
                <div class="card-body">
                    <h4 class="card-title">Seo Meta Tags</h4>
                    <!---meta title--->
                    <div class="form-group row">
                        <label for="metaTitle" class="col-sm-3 col-form-label">Meta Title <span class="text-danger">*</span></label>
                        <div class="col-sm-9">
                            <input type="text" name="metaTitle" class="form-control" id="metaTitle">
                        <?php $__errorArgs = ['metaTitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                        <!---meta description--->
                    <div class="form-group row">
                        <label for="metaDescription" class="col-sm-3 col-form-label">MetaDescription</label>
                        <div class="col-sm-9">
                            <textarea name="metaDescription" id="metaDescription" cols="30" rows="10" class="form-control"></textarea>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <!----Featured status-->
            <div class="card mt-5">
                <div class="card-body">
                    <h4 class="card-title">Featured</h4>
                    <div class="form-group row">
                        <label class="col-sm-6 col-form-label" style="margin-top:9px;">Status</label>
                        <div class="col-sm-3">
                          <div class="form-check">
                            <label class="form-check-label">
                              <input type="radio" class="form-check-input" name="featured" value="off" checked>off </label>
                          </div>
                        </div>
                        <div class="col-sm-3">
                          <div class="form-check">
                            <label class="form-check-label">
                              <input type="radio" class="form-check-input" name="featured" value="on">on </label>
                          </div>
                        </div>
                    </div>
                </div>
            </div>
            <!----Todays Deal status-->
            <div class="card mt-2">
                <div class="card-body">
                    <h4 class="card-title">Todays Deal</h4>
                    <div class="form-group row">
                        <label class="col-sm-6 col-form-label" style="margin-top:9px;">Status</label>
                        <div class="col-sm-3">
                          <div class="form-check">
                            <label class="form-check-label">
                              <input type="radio" class="form-check-input" name="todayDeal" value="off" checked>off </label>
                          </div>
                        </div>
                        <div class="col-sm-3">
                          <div class="form-check">
                            <label class="form-check-label">
                              <input type="radio" class="form-check-input" name="todayDeal" value="on">on </label>
                          </div>
                        </div>
                    </div>
                </div>
            </div>
             <!----Flash Deal-->
             <div class="card mt-2">
                <div class="card-body">
                    <h4 class="card-title">Flash Deal</h4>
                    <div class="form-group">
                        <label class="col-form-label">Add to Flash</label>
                        <select name="addToFlash" class="form-control">
                            <option value="">Select Flash</option>
                            <option value="winterSell">Winter Sell</option>
                            <option value="flashDeal">Flash Deal</option>
                            <option value="flashSeal">Flash Seal</option>
                        </select>
                    </div>
                </div>
            </div>
            <!---- vat and tax-->
            <div class="card mt-2">
                <div class="card-body">
                    <h4 class="card-title">Vat and Tax</h4>
                    <div class="form-group">
                        <label class="col-form-label">Vat <span>(taka)</span></label>
                        <input type="number" name="vat" class="form-control">
                    </div>
                    <div class="form-group">
                        <label class="col-form-label">Tax <span>(taka)</span></label>
                        <input type="number" name="tax" class="form-control">
                    </div>
                </div>
            </div>
        </div>

        <div class="mt-4">
            <button type="submit" class="btn btn-primary mr-2">Save & Publish</button>
        </div>
    </div>
</form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
   <script>
     $('#category').change(function(){
        var category = $('#category').val();
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $.ajax({
            type:'POST',
            url:'/getCategory',
            data:{'category_id':category},
            success:function(data){
                $('#subcategory').html(data);

            }
        });
     });
   </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HomeHutBd\resources\views/admin/product/add_product.blade.php ENDPATH**/ ?>