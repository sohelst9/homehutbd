<?php $__env->startSection('main_container'); ?>
    <style>

    </style>
    


    <!-- Categories Start -->
    <div class="container-fluid cate_section">
        <div class="mb-2 head_title">
            <h2>Categories</h2>
        </div>
        <div class="row px-xl-5 pb-3">
            <?php
                $cate = categories();
            ?>
            <?php $__currentLoopData = $cate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $catProductCount = \App\Models\Product::catProductCount($category->id);
                ?>
                <div class="col-lg-2 col-md-3 col-sm-4 pb-1">
                    <div class="cat-item d-flex flex-column border mb-4" style="padding: 30px;">
                        <a href="<?php echo e(route('category.shop', $category->id)); ?>" class="catProduct_count">
                            <p class="text-center"><?php echo e($catProductCount); ?> Products</p>
                        </a>
                        <a href="<?php echo e(route('category.shop', $category->id)); ?>"
                            class="cat-img position-relative overflow-hidden mb-3">
                            <img class="img-fluid" src="<?php echo e(asset('storage/backend/upload/category/' . $category->banner)); ?>"
                                alt="">
                        </a>
                        <h5 class="font-weight-semi-bold m-0 cat_name"><?php echo e(substr($category->name, 0, 20) . '..'); ?></h5>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <!-- Categories End -->


    <!-- Offer Start -->
    


    <!-- Products to day deal -->
    <div class="container-fluid">
        <div class="mb-2 head_title">
            <h2>To Day Deal</h2>
            <a href="">Shop More</a>
        </div>
        <div class="row px-xl-5 pb-3">
            <?php $__currentLoopData = collect($toDayDeal_products)->take(6); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $toDayDeal_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-2 col-md-3 col-sm-4 pb-1">
                    <div class="card product-item border-0 mb-4">
                        <div class="card-header product-img position-relative overflow-hidden bg-transparent border p-0">
                            <a href="<?php echo e(route('single.Product', $toDayDeal_product->id)); ?>"><img
                                    class="img-fluid w-100 product_image"
                                    src="<?php echo e(asset('storage/backend/upload/product/thumbnailImage/' . $toDayDeal_product->thumbnailImage)); ?>"
                                    alt=""></a>
                        </div>
                        <div class="card-body border-left border-right text-center p-0 pt-4 pb-3">
                            <a href="<?php echo e(route('single.Product', $toDayDeal_product->id)); ?>"
                                style="text-decoration: none;">
                                <h6 class="pr_cate"><?php echo e($toDayDeal_product->subcategory->subcategory); ?></h6>
                                <h6 class="product_name"><?php echo e(substr($toDayDeal_product->productName, 0, 20) . '...'); ?></h6>
                            </a>
                            <div class="d-flex justify-content-center">
                                <h6 style="font-size: 14px; color:rgb(221, 69, 27);">&#2547;
                                    <?php echo e($toDayDeal_product->after_discount); ?></h6>
                                <h6 class="text-muted ml-2" style="font-size: 12px; color:#646060; margin-top:1px;">
                                    <del>&#2547; <?php echo e($toDayDeal_product->productPrice); ?></del></h6>
                            </div>
                        </div>
                        <div class="card-footer d-flex justify-content-between bg-light border product_cart">
                            <a href="" class="btn btn-sm text-dark p-0"><i
                                    class="fas fa-shopping-cart text-primary mr-1"></i>Add To Cart</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <!-- to day deal -->

    <!-- All Products -->
    <div class="container-fluid">
        <div class="mb-2 head_title">
            <h2>All Products</h2>
            <a href="">Shop More</a>
        </div>
        <div class="row px-xl-5 pb-3">
            <?php $__currentLoopData = collect($products)->take(18); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-2 col-md-3 col-sm-4 pb-1">
                    <div class="card product-item border-0 mb-4">
                        <div class="card-header product-img position-relative overflow-hidden bg-transparent border p-0">

                           <a href="<?php echo e(route('single.Product', $product->id)); ?>"> <img class="img-fluid w-100 product_image"
                            src="<?php echo e(asset('storage/backend/upload/product/thumbnailImage/' . $product->thumbnailImage)); ?>"
                            alt="">
                    </div></a>
                        <div class="card-body border-left border-right text-center p-0 pt-4 pb-3">
                            <a href="<?php echo e(route('single.Product', $product->id)); ?>"
                                style="text-decoration: none;">
                                <h6 class="pr_cate"><?php echo e($product->subcategory->subcategory); ?></h6>
                                <h6 class="product_name"><?php echo e(substr($product->productName, 0, 20) . '...'); ?></h6>
                            </a>
                            <div class="d-flex justify-content-center">
                                <h6 style="font-size: 14px; color:rgb(221, 69, 27);">&#2547; <?php echo e($product->after_discount); ?></h6>
                                <h6 class="text-muted ml-2" style="font-size: 12px; color:#646060; margin-top:1px;">
                                    <del>&#2547; <?php echo e($product->productPrice); ?></del></h6>
                            </div>
                        </div>
                        <div class="card-footer d-flex justify-content-between bg-light border product_cart">
                            <a href="" class="btn btn-sm text-dark p-0"><i
                                    class="fas fa-shopping-cart text-primary mr-1"></i>Add To Cart</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <!-- All Products -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HomeHutBd\resources\views/frontend/index.blade.php ENDPATH**/ ?>