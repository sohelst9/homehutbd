@extends('layouts.frontend.app')
@section('main_container')
    <style>

    </style>
    {{-- <!-- Featured Start -->
 <div class="container-fluid pt-5">
    <div class="row px-xl-5 pb-3">
        <div class="col-lg-3 col-md-6 col-sm-12 pb-1">
            <div class="d-flex align-items-center border mb-4" style="padding: 30px;">
                <h1 class="fa fa-check text-primary m-0 mr-3"></h1>
                <h5 class="font-weight-semi-bold m-0">Quality Product</h5>
            </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-12 pb-1">
            <div class="d-flex align-items-center border mb-4" style="padding: 30px;">
                <h1 class="fa fa-shipping-fast text-primary m-0 mr-2"></h1>
                <h5 class="font-weight-semi-bold m-0">Free Shipping</h5>
            </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-12 pb-1">
            <div class="d-flex align-items-center border mb-4" style="padding: 30px;">
                <h1 class="fas fa-exchange-alt text-primary m-0 mr-3"></h1>
                <h5 class="font-weight-semi-bold m-0">14-Day Return</h5>
            </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-12 pb-1">
            <div class="d-flex align-items-center border mb-4" style="padding: 30px;">
                <h1 class="fa fa-phone-volume text-primary m-0 mr-3"></h1>
                <h5 class="font-weight-semi-bold m-0">24/7 Support</h5>
            </div>
        </div>
    </div>
</div>
<!-- Featured End --> --}}


    <!-- Categories Start -->
    <div class="container-fluid cate_section">
        <div class="mb-2 head_title">
            <h2>Categories</h2>
        </div>
        <div class="row px-xl-5 pb-3">
            @php
                $cate = categories();
            @endphp
            @foreach ($cate as $category)
                @php
                    $catProductCount = \App\Models\Product::catProductCount($category->id);
                @endphp
                <div class="col-lg-2 col-md-3 col-sm-4 pb-1">
                    <div class="cat-item d-flex flex-column border mb-4" style="padding: 30px;">
                        <a href="{{ route('category.shop', $category->id) }}" class="catProduct_count">
                            <p class="text-center">{{ $catProductCount }} Products</p>
                        </a>
                        <a href="{{ route('category.shop', $category->id) }}"
                            class="cat-img position-relative overflow-hidden mb-3">
                            <img class="img-fluid" src="{{ asset('storage/backend/upload/category/' . $category->banner) }}"
                                alt="">
                        </a>
                        <h5 class="font-weight-semi-bold m-0 cat_name">{{ substr($category->name, 0, 20) . '..' }}</h5>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
    <!-- Categories End -->


    <!-- Offer Start -->
    {{-- <div class="container-fluid offer pt-5">
    <div class="row px-xl-5">
        <div class="col-md-6 pb-4">
            <div class="position-relative bg-secondary text-center text-md-right text-white mb-2 py-5 px-5">
                <img src="{{ asset('frontend/img/offer-1.png')}}" alt="">
                <div class="position-relative" style="z-index: 1;">
                    <h5 class="text-uppercase text-primary mb-3">20% off the all order</h5>
                    <h1 class="mb-4 font-weight-semi-bold">Spring Collection</h1>
                    <a href="" class="btn btn-outline-primary py-md-2 px-md-3">Shop Now</a>
                </div>
            </div>
        </div>
        <div class="col-md-6 pb-4">
            <div class="position-relative bg-secondary text-center text-md-left text-white mb-2 py-5 px-5">
                <img src="{{ asset('frontend/img/offer-2.png')}}" alt="">
                <div class="position-relative" style="z-index: 1;">
                    <h5 class="text-uppercase text-primary mb-3">20% off the all order</h5>
                    <h1 class="mb-4 font-weight-semi-bold">Winter Collection</h1>
                    <a href="" class="btn btn-outline-primary py-md-2 px-md-3">Shop Now</a>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Offer End --> --}}


    <!-- Products to day deal -->
    <div class="container-fluid">
        <div class="mb-2 head_title">
            <h2>To Day Deal</h2>
            <a href="">Shop More</a>
        </div>
        <div class="row px-xl-5 pb-3">
            @foreach (collect($toDayDeal_products)->take(6) as $toDayDeal_product)
                <div class="col-lg-2 col-md-3 col-sm-4 pb-1">
                    <div class="card product-item border-0 mb-4">
                        <div class="card-header product-img position-relative overflow-hidden bg-transparent border p-0">
                            <a href="{{ route('single.Product', $toDayDeal_product->id) }}"><img
                                    class="img-fluid w-100 product_image"
                                    src="{{ asset('storage/backend/upload/product/thumbnailImage/' . $toDayDeal_product->thumbnailImage) }}"
                                    alt=""></a>
                        </div>
                        <div class="card-body border-left border-right text-center p-0 pt-4 pb-3">
                            <a href="{{ route('single.Product', $toDayDeal_product->id) }}"
                                style="text-decoration: none;">
                                <h6 class="pr_cate">{{ $toDayDeal_product->subcategory->subcategory }}</h6>
                                <h6 class="product_name">{{ substr($toDayDeal_product->productName, 0, 20) . '...' }}</h6>
                            </a>
                            <div class="d-flex justify-content-center">
                                <h6 style="font-size: 14px; color:rgb(221, 69, 27);">&#2547;
                                    {{ $toDayDeal_product->after_discount }}</h6>
                                <h6 class="text-muted ml-2" style="font-size: 12px; color:#646060; margin-top:1px;">
                                    <del>&#2547; {{ $toDayDeal_product->productPrice }}</del></h6>
                            </div>
                        </div>
                        <div class="card-footer d-flex justify-content-between bg-light border product_cart">
                            <a href="" class="btn btn-sm text-dark p-0"><i
                                    class="fas fa-shopping-cart text-primary mr-1"></i>Add To Cart</a>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
    <!-- to day deal -->

    <!-- All Products -->
    <div class="container-fluid">
        <div class="mb-2 head_title">
            <h2>All Products</h2>
            <a href="">Shop More</a>
        </div>
        <div class="row px-xl-5 pb-3">
            @foreach (collect($products)->take(18) as $product)
                <div class="col-lg-2 col-md-3 col-sm-4 pb-1">
                    <div class="card product-item border-0 mb-4">
                        <div class="card-header product-img position-relative overflow-hidden bg-transparent border p-0">

                           <a href="{{ route('single.Product', $product->id) }}"> <img class="img-fluid w-100 product_image"
                            src="{{ asset('storage/backend/upload/product/thumbnailImage/' . $product->thumbnailImage) }}"
                            alt="">
                    </div></a>
                        <div class="card-body border-left border-right text-center p-0 pt-4 pb-3">
                            <a href="{{ route('single.Product', $product->id) }}"
                                style="text-decoration: none;">
                                <h6 class="pr_cate">{{ $product->subcategory->subcategory }}</h6>
                                <h6 class="product_name">{{ substr($product->productName, 0, 20) . '...' }}</h6>
                            </a>
                            <div class="d-flex justify-content-center">
                                <h6 style="font-size: 14px; color:rgb(221, 69, 27);">&#2547; {{ $product->after_discount }}</h6>
                                <h6 class="text-muted ml-2" style="font-size: 12px; color:#646060; margin-top:1px;">
                                    <del>&#2547; {{ $product->productPrice }}</del></h6>
                            </div>
                        </div>
                        <div class="card-footer d-flex justify-content-between bg-light border product_cart">
                            <a href="" class="btn btn-sm text-dark p-0"><i
                                    class="fas fa-shopping-cart text-primary mr-1"></i>Add To Cart</a>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
    <!-- All Products -->
@endsection
